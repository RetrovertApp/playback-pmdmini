optasm vedse;
optlink vedse;
